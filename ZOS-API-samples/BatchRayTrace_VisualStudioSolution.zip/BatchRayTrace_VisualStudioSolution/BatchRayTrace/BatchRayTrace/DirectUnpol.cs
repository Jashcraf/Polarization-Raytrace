﻿
using System;
using System.Text;
using ZOSAPI.Tools.RayTrace;

namespace BatchRayTrace
{
    

    public class ReadDirectUnpolData
    {
        private IBatchRayTrace RayTrace;
        private IRayTraceDirectUnpolData RayTraceType;
        

        private bool IsFinished;

        public ReadDirectUnpolData(IBatchRayTrace rt, IRayTraceDirectUnpolData rtt)
        {
            RayTrace = rt;
            RayTraceType = rtt;
            IsFinished = false;
        }

        public DirectUnpolOutput InitializeOutput(
            int maxSegments,
            bool incRayNumber = true,
            bool incErrorCode = true,
            bool incVignetteCode = true,
            bool incXYZ = true,
            bool incLMN = true,
            bool incL2M2N2 = true,
            bool incOPD = true,
            bool incIntensity = true
            )
        {
            maxSegments = (maxSegments) * (maxSegments);
            if (maxSegments <= 0)
                return null;
            
            DirectUnpolOutput output = new DirectUnpolOutput();
            output.MaxSegments = maxSegments;

            output.MaxRays = RayTraceType.MaxRays;
            
            if (incRayNumber) output.rayNumber = new int[maxSegments];
            if (incErrorCode) output.errorCode = new int[maxSegments];
            if (incVignetteCode) output.vignetteCode = new int[maxSegments];
            if (incXYZ)
            {
                output.X = new double[maxSegments];
                output.Y = new double[maxSegments];
                output.Z = new double[maxSegments];
            }
            if (incLMN)
            {
                output.L = new double[maxSegments];
                output.M = new double[maxSegments];
                output.N = new double[maxSegments];
            }
            if (incL2M2N2)
            {
                output.l2 = new double[maxSegments];
                output.m2 = new double[maxSegments];
                output.n2 = new double[maxSegments];
            }
            
            if (incIntensity) output.intensity = new double[maxSegments];

            return output;
        }

        public int ReadNextBlock(DirectUnpolOutput output)
        {
            if (IsFinished || output == null)
                return 0;

            bool incRayNumber = output.rayNumber != null;


            bool incErrorCode = output.errorCode != null;
            bool incVignetteCode = output.vignetteCode != null;
            bool incXYZ = output.X != null;
            bool incLMN = output.L != null;
            bool incL2M2N2 = output.l2 != null;
            bool incIntensity = output.intensity != null;

            // run raytrace
            RayTrace.RunAndWaitForCompletion();

            RayTraceType.StartReadingResults();

            int maxSeg = output.MaxSegments;
            int incrementer = 0;
            bool full = false;
            while (!full)
            {
                if (incrementer > maxSeg)
                {
                    break;
                }
                
                if (RayTraceType.ReadNextResult(
                    out int rayNumber,
                    out int errorCode,
                    out int vignetteCode,
                    out double X,
                    out double Y,
                    out double Z,
                    out double L,
                    out double M,
                    out double N,
                    out double l2,
                    out double m2,
                    out double n2,
                    out double intensity
                ))
                {
                    if (incRayNumber) output.rayNumber[incrementer] = rayNumber;
                    if (incErrorCode) output.errorCode[incrementer] = errorCode;
                    if (incVignetteCode) output.vignetteCode[incrementer] = vignetteCode;
                    if (incXYZ)
                    {
                        output.X[incrementer] = X;
                        output.Y[incrementer] = Y;
                        output.Z[incrementer] = Z;
                    }
                    if (incLMN)
                    {
                        output.L[incrementer] = L;
                        output.M[incrementer] = M;
                        output.N[incrementer] = N;
                    }
                    if (incL2M2N2)
                    {
                        output.l2[incrementer] = l2;
                        output.m2[incrementer] = m2;
                        output.n2[incrementer] = n2;
                    }
                    if (incIntensity) output.intensity[incrementer] = intensity;


                    ++incrementer;
                }
                else
                {
                    IsFinished = true;
                    break;
                }
            }

            return incrementer;
        }

        public bool AddRay(int waveNumber, double[] X, double[] Y, double[] Z, double[] L, double[] M, double[] N)
        {
            for (var i = 0; i < X.Length; i++)
            {
                RayTraceType.AddRay(waveNumber, X[i], Y[i], Z[i], L[i], M[i], N[i]);
            }

            return true;
        }

        public bool ClearData()
        {
            RayTraceType.ClearData();
            return true;
        }

        public int NumberOfRays()
        {
            return RayTraceType.NumberOfRays;
        }
    }

    public class DirectUnpolOutput
    {
        internal int MaxSegments;


        public int MaxRays;
        public int[] rayNumber;
        public int[] errorCode;
        public int[] vignetteCode;
        public double[] X;
        public double[] Y;
        public double[] Z;
        public double[] L;
        public double[] M;
        public double[] N;
        public double[] l2;
        public double[] m2;
        public double[] n2;
        public double[] intensity;
    }


}
