﻿using ZOSAPI.Tools.RayTrace;

namespace BatchRayTrace
{
    public class ReadZRDData
    {
        private IZRDReaderResults DataSource;

        private int RayNumber;
        private int Waveincrementer;
        private double WavelengthUM;
        private int NumSegments;
        private bool IsFinished;

        public ReadZRDData(IZRDReaderResults zrdData)
        {
            this.DataSource = zrdData;
            IsFinished = false;
        }


        
        public ZRDOutput InitializeOutput(
            long maxSegments,
            bool incRayNumber = true,
            bool incWaveincrementer = true,
            bool incWavelength = true,
            bool incSegmentNumber = true,
            bool incLevel = true,
            bool incParent = true,
            bool incHitObj = true,
            bool incHitFace = true,
            bool incInsideOf = true,
            bool incStatus = true,
            bool incXYZ = true,
            bool incLMN = true,
            bool incField = true,
            bool incIntensity = true,
            bool incPathLen = true,

            bool incXYBin = true,
            bool incLMBin = true,
            bool incNorm = true,
            bool incIndex = true,
            bool incStartingPhase = true,
            bool incPhaseOf = true,
            bool incPhaseAt = true
            )
        {
            if (maxSegments <= 0)
                return null;

            ZRDOutput output = new BatchRayTrace.ZRDOutput();
            output.MaxSegments = maxSegments;

            if (incRayNumber) output.RayNumber = new long[maxSegments];
            if (incWaveincrementer) output.Waveincrementer = new long[maxSegments];
            if (incWavelength) output.WlUM = new double[maxSegments];
            if (incSegmentNumber) output.SegmentNumber = new long[maxSegments];
            if (incLevel) output.Level = new long[maxSegments];
            if (incParent) output.Parent = new long[maxSegments];
            if (incHitObj) output.HitObject = new long[maxSegments];
            if (incHitFace) output.HitFace = new long[maxSegments];
            if (incInsideOf) output.InsideOf = new long[maxSegments];
            if (incSegmentNumber) output.Status = new long[maxSegments];
            if (incXYZ)
            {
                output.X = new double[maxSegments];
                output.Y = new double[maxSegments];
                output.Z = new double[maxSegments];
            }

            //testing

            if (incLevel)
            {
                output.L = new double[maxSegments];
                output.M = new double[maxSegments];
                output.N = new double[maxSegments];
            }
            if (incField)
            {
                output.Exr = new double[maxSegments];
                output.Exi = new double[maxSegments];
                output.Eyr = new double[maxSegments];
                output.Eyi = new double[maxSegments];
                output.Ezr = new double[maxSegments];
                output.Ezi = new double[maxSegments];
            }
            if (incIntensity) output.Intensity = new double[maxSegments];
            if (incPathLen) output.PathLen = new double[maxSegments];

            if (incXYBin) output.xybin = new long[maxSegments];
            if (incLMBin) output.lmbin = new long[maxSegments];
            if (incNorm)
            {
                output.xNorm = new double[maxSegments];
                output.yNorm = new double[maxSegments];
                output.zNorm = new double[maxSegments];
            }
            if (incIndex) output.index = new double[maxSegments];
            if (incStartingPhase) output.startingPhase = new double[maxSegments];
            if (incPhaseOf) output.phaseOf = new double[maxSegments];
            if (incPhaseAt) output.phaseAt = new double[maxSegments];

            return output;
        }

        public long ReadNextBlock(ZRDOutput output)
        {
            if (IsFinished || output == null)
                return 0;

            bool incRayNumber = output.RayNumber != null;
            bool incWaveincrementer = output.Waveincrementer != null;
            bool incWavelength = output.WlUM != null;
            bool incSegmentNumber = output.SegmentNumber != null;
            bool incLevel = output.Level != null;
            bool incParent = output.Parent != null;
            bool incHitObj = output.HitObject != null;
            bool incHitFace = output.HitFace != null;
            bool incInside = output.InsideOf != null;
            bool incStatus = output.Status != null;
            bool incXYZ = output.X != null;
            bool incLMN = output.L != null;
            bool incField = output.Exr != null;
            bool incIntensity = output.Intensity != null;
            bool incPL = output.PathLen != null;

            bool incXYBin = output.xybin != null;
            bool incLMBin = output.lmbin != null;
            bool incNorm = output.xNorm != null;
            bool incIndex = output.index != null;
            bool incStartingPhase = output.startingPhase != null;
            bool incPhaseOf = output.phaseOf != null;
            bool incPhaseAt = output.phaseAt != null;

            long maxSeg = output.MaxSegments;
            long incrementer = 0;
            bool full = false;
            while (!full)
            {
                if (incrementer + NumSegments > maxSeg)
                {
                    break;
                }

                int segNum = 1;
                while (NumSegments > 0)
                {
                    int segmentLevel, segmentParent, hitObj, hitFace, insideOf, xybin, lmbin;
                    double x, y, z, l, m, n, exr, exi, eyr, eyi, ezr, ezi, intensity, pathLength, xNorm, yNorm, zNorm, index, startingPhase, phaseOf, phaseAt;
                    RayStatus status;
                    if (DataSource.ReadNextSegmentFull(
                        out segmentLevel,
                        out segmentParent,
                        out hitObj,
                        out hitFace,
                        out insideOf,
                        out status,
                        out x,
                        out y,
                        out z,
                        out l,
                        out m,
                        out n,
                        out exr,
                        out exi,
                        out eyr,
                        out eyi,
                        out ezr,
                        out ezi,
                        out intensity,
                        out pathLength,
                        out xybin,
                        out lmbin,
                        out xNorm,
                        out yNorm,
                        out zNorm,
                        out index,
                        out startingPhase,
                        out phaseOf,
                        out phaseAt
                        ))
                    {
                        if (incRayNumber) output.RayNumber[incrementer] = RayNumber;
                        if (incWaveincrementer) output.Waveincrementer[incrementer] = Waveincrementer;
                        if (incWavelength) output.WlUM[incrementer] = WavelengthUM;
                        if (incSegmentNumber) output.SegmentNumber[incrementer] = segNum;
                        if (incLevel) output.Level[incrementer] = segmentLevel;
                        if (incParent) output.Parent[incrementer] = segmentParent;
                        if (incHitObj) output.HitObject[incrementer] = hitObj;
                        if (incHitFace) output.HitFace[incrementer] = hitFace;
                        if (incInside) output.InsideOf[incrementer] = insideOf;
                        // MATLAB doesn't handle enum types very well, so convert to an int
                        // We could also convert to a series of bool's for the various statuses
                        if (incStatus) output.Status[incrementer] = (int)status;
                        if (incXYZ)
                        {
                            output.X[incrementer] = x;
                            output.Y[incrementer] = y;
                            output.Z[incrementer] = z;
                        }
                        if (incLMN)
                        {
                            output.L[incrementer] = l;
                            output.M[incrementer] = m;
                            output.N[incrementer] = n;
                        }
                        if (incField)
                        {
                            output.Exr[incrementer] = exr;
                            output.Exi[incrementer] = exi;
                            output.Eyr[incrementer] = eyr;
                            output.Eyi[incrementer] = eyi;
                            output.Ezr[incrementer] = ezr;
                            output.Ezi[incrementer] = ezi;
                        }
                        if (incIntensity) output.Intensity[incrementer] = intensity;
                        if (incPL) output.PathLen[incrementer] = pathLength;

                        if (incXYBin) output.xybin[incrementer] = xybin;
                        if (incLMBin) output.lmbin[incrementer] = lmbin;
                        if (incNorm)
                        {
                            output.xNorm[incrementer] = xNorm;
                            output.yNorm[incrementer] = yNorm;
                            output.zNorm[incrementer] = zNorm;
                        }
                        if (incIndex) output.index[incrementer] = index;
                        if (incStartingPhase) output.startingPhase[incrementer] = startingPhase;
                        if (incPhaseOf) output.phaseOf[incrementer] = phaseOf;
                        if (incPhaseAt) output.phaseAt[incrementer] = phaseAt;

                        --NumSegments;
                        ++segNum;
                        ++incrementer;
                    }
                    else
                    {
                        // What happened?
                        NumSegments = 0;
                    }
                }

                if (!DataSource.ReadNextResult(
                    out RayNumber,
                    out Waveincrementer,
                    out WavelengthUM,
                    out NumSegments))
                {
                    IsFinished = true;
                    break;
                }
            }

            return incrementer;
        }
    }

    public class ZRDOutput
    {
        internal long MaxSegments;
        public long[] RayNumber;
        public long[] Waveincrementer;
        public double[] WlUM;
        public long[] SegmentNumber;
        public long[] Level;
        public long[] Parent;
        public long[] HitObject;
        public long[] HitFace;
        public long[] InsideOf;
        public long[] Status;
        public double[] X;
        public double[] Y;
        public double[] Z;
        public double[] L;
        public double[] M;
        public double[] N;
        public double[] Exr;
        public double[] Exi;
        public double[] Eyr;
        public double[] Eyi;
        public double[] Ezr;
        public double[] Ezi;
        public double[] Intensity;
        public double[] PathLen;

        public long[] xybin;
        public long[] lmbin;
        public double[] xNorm;
        public double[] yNorm;
        public double[] zNorm;
        public double[] index;
        public double[] startingPhase;
        public double[] phaseOf;
        public double[] phaseAt;
    }


}
