﻿
using System;
using System.Text;
using ZOSAPI.Tools.RayTrace;

namespace BatchRayTrace
{
    public class ReadNormPolData
    {
        private IBatchRayTrace RayTrace;
        private IRayTraceNormPolData RayTraceType;


        private bool IsFinished;

        public ReadNormPolData(IBatchRayTrace rt, IRayTraceNormPolData rtt)
        {
            RayTrace = rt;
            RayTraceType = rtt;
            IsFinished = false;
        }

        public NormPolOutput InitializeOutput(
            int maxSegments,
            bool incRayNumber = true,
            bool incErrorCode = true,
            bool incXYZ = true,
            bool incLMN = true,
            bool incField = true,
            bool incOPD = true,
            bool incIntensity = true
            )
        {
            maxSegments = (maxSegments) * (maxSegments);
            if (maxSegments <= 0)
                return null;

            NormPolOutput output = new NormPolOutput();
            output.MaxSegments = maxSegments;

            output.MaxRays = RayTraceType.MaxRays;

            if (incRayNumber) output.rayNumber = new int[maxSegments];
            if (incErrorCode) output.ErrorCode = new int[maxSegments];
            if (incXYZ)
            {
                output.xo = new double[maxSegments];
                output.yo = new double[maxSegments];
                output.zo = new double[maxSegments];
            }
            if (incLMN)
            {
                output.lo = new double[maxSegments];
                output.mo = new double[maxSegments];
                output.no = new double[maxSegments];
            }
            if (incField)
            {
                output.exr = new double[maxSegments];
                output.exi = new double[maxSegments];
                output.eyr = new double[maxSegments];
                output.eyi = new double[maxSegments];
                output.ezr = new double[maxSegments];
                output.ezi = new double[maxSegments];
            }
            if (incIntensity) output.intensity = new double[maxSegments];

            return output;
        }

        public int ReadNextBlock(NormPolOutput output)
        {
            if (IsFinished || output == null)
                return 0;

            bool incRayNumber = output.rayNumber != null;
            bool incErrorCode = output.ErrorCode != null;
            bool incXYZ = output.xo != null;
            bool incLMN = output.lo != null;
            bool incField = output.exr != null;
            bool incIntensity = output.intensity != null;

            // run raytrace
            RayTrace.RunAndWaitForCompletion();

            RayTraceType.StartReadingResults();



            int maxSeg = output.MaxSegments;
            int incrementer = 0;
            bool full = false;
            while (!full)
            {
                if (incrementer > maxSeg)
                {
                    break;
                }

                if (RayTraceType.ReadNextResultFull(
                    out int rayNumber,
                    out int ErrorCode,
                    out double xo,
                    out double yo,
                    out double zo,
                    out double lo,
                    out double mo,
                    out double no,
                    out double exr,
                    out double exi,
                    out double eyr,
                    out double eyi,
                    out double ezr,
                    out double ezi,
                    out double intensity
                ))
                {
                    if (incRayNumber) output.rayNumber[incrementer] = rayNumber;
                    if (incErrorCode) output.ErrorCode[incrementer] = ErrorCode;

                    if (incXYZ)
                    {
                        output.xo[incrementer] = xo;
                        output.yo[incrementer] = yo;
                        output.zo[incrementer] = zo;
                    }
                    if (incLMN)
                    {
                        output.lo[incrementer] = lo;
                        output.mo[incrementer] = mo;
                        output.no[incrementer] = no;
                    }
                    if (incField)
                    {
                        output.exr[incrementer] = exr;
                        output.exi[incrementer] = exi;
                        output.eyr[incrementer] = eyr;
                        output.eyi[incrementer] = eyi;
                        output.ezr[incrementer] = ezr;
                        output.ezi[incrementer] = ezi;
                    }
                    if (incIntensity) output.intensity[incrementer] = intensity;


                    ++incrementer;
                }
                else
                {
                    IsFinished = true;
                    break;
                }
            }


            return incrementer;
        }


        public bool AddRay(int waveNumber, double[] Hx, double[] Hy, double[] Px, double[] Py, double[] exr, double[] exi, double[] eyr, double[] eyi, double[] ezr, double[] ezi)
        {
            for (var i = 0; i < Hx.Length; i++)
            {
                RayTraceType.AddRay(waveNumber, Hx[i], Hy[i], Px[i], Py[i], exr[i], exi[i], eyr[i], eyi[i], ezr[i], ezi[i]);
            }

            return true;
        }

        public bool ClearData()
        {
            RayTraceType.ClearData();
            return true;
        }

        public int NumberOfRays()
        {
            return RayTraceType.NumberOfRays;
        }
    }

    public class NormPolOutput
    {
        internal int MaxSegments;

        public int MaxRays;
        public int[] rayNumber;
        public int[] ErrorCode;
        public double[] xo;
        public double[] yo;
        public double[] zo;
        public double[] lo;
        public double[] mo;
        public double[] no;
        public double[] exr;
        public double[] exi;
        public double[] eyr;
        public double[] eyi;
        public double[] ezr;
        public double[] ezi;
        public double[] intensity;
    }
}

